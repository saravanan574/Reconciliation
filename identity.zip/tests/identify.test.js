const data = {email:"ad@gmail.com",phoneNo:"9876543210"};

fetch("http://localhost:3000/identify",{
  method:"POST",
  headers: {"content-type":"application/json"},
  body:JSON.stringify(data)
})
.then(res => res.json())
.then(data => console.log(data))
.catch(err => console.error(err))