require("dotenv").config();
const mongoose = require("mongoose");
const app = require("./app");

const PORT = process.env.PORT || 3000;
const MONGODB_URI =
  process.env.MONGODB_URI || "mongodb://localhost:27017/identity_reconciliation";

/**
 * Connect to MongoDB then start the HTTP server.
 * Exits the process on a fatal DB connection error.
 */
async function bootstrap() {
  try {
    await mongoose.connect(MONGODB_URI, {
      // Recommended options to suppress deprecation warnings
      serverSelectionTimeoutMS: 5000,
    });
    console.log(`[DB] Connected to MongoDB at ${MONGODB_URI}`);

    app.listen(PORT, () => {
      console.log(`[Server] Identity Reconciliation Service running on port ${PORT}`);
      console.log(`[Server] POST http://localhost:${PORT}/identify`);
      console.log(`[Server] GET  http://localhost:${PORT}/health`);
    });
  } catch (err) {
    console.error("[DB] Failed to connect to MongoDB:", err.message);
    process.exit(1);
  }
}

// Graceful shutdown on SIGINT / SIGTERM
process.on("SIGINT", async () => {
  console.log("\n[Server] Shutting down gracefully...");
  await mongoose.disconnect();
  process.exit(0);
});

bootstrap();
