const mongoose = require("mongoose");

/**
 * Contact Schema
 * Represents a single contact entry in the identity graph.
 *
 * linkPrecedence:
 *   "primary" — the root node of a contact cluster
 *   "secondary" — linked to a primary contact via linkedId
 */
const contactSchema = new mongoose.Schema(
  {
    phoneNumber: {
      type: String,
      default: null,
      trim: true,
    },
    email: {
      type: String,
      default: null,
      trim: true,
      lowercase: true,
    },
    // ID of the primary contact this entry is linked to (null if primary itself)
    linkedId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Contact",
      default: null,
    },
    linkPrecedence: {
      type: String,
      enum: ["primary", "secondary"],
      required: true,
      default: "primary",
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true, // createdAt + updatedAt added automatically
  }
);

// Index for fast lookups by email and phoneNumber
contactSchema.index({ email: 1 });
contactSchema.index({ phoneNumber: 1 });
contactSchema.index({ linkedId: 1 });

module.exports = mongoose.model("Contact", contactSchema);
