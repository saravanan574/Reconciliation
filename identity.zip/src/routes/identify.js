const express = require("express");
const { identify } = require("../controllers/identifyController");

const router = express.Router();

// POST /identify — core reconciliation endpoint
router.post("/identify", identify);

module.exports = router;
