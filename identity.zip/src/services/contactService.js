const Contact = require("../models/Contact");

/**
 * identifyContact
 *
 * Core identity-reconciliation logic:
 * 1. Find all existing contacts that match the incoming email or phone.
 * 2. If none → create a brand-new primary contact.
 * 3. If matches exist → figure out the true primary (oldest createdAt),
 *    demote any competing primaries to secondary, and create a secondary
 *    entry for any genuinely new information.
 * 4. Return a consolidated view of the entire contact cluster.
 */
async function identifyContact(email, phoneNumber) {
  // ── 1. Find all contacts matching email OR phone ──────────────────────────
  const orClause = [];
  if (email) orClause.push({ email });
  if (phoneNumber) orClause.push({ phoneNumber });

  const matchedContacts = await findActive({ $or: orClause });

  // ── 2. No matches → create a new primary ────────────────────────────────
  if (matchedContacts.length === 0) {
    const newPrimary = await Contact.create({
      email: email || null,
      phoneNumber: phoneNumber || null,
      linkPrecedence: "primary",
      linkedId: null,
    });
    return buildResponse(newPrimary, []);
  }

  // ── 3. Gather all cluster IDs referenced by the matches ──────────────────
  const primaryIds = new Set();
  for (const c of matchedContacts) {
    if (c.linkPrecedence === "primary") {
      primaryIds.add(c._id.toString());
    } else if (c.linkedId) {
      primaryIds.add(c.linkedId.toString());
    }
  }

  // Fetch the full cluster: primary docs + all their secondaries
  const idList = [...primaryIds];
  const allClusterContacts = await findActive({
    $or: [
      { _id: { $in: idList } },
      { linkedId: { $in: idList } },
    ],
  });

  // ── 4. Elect oldest contact as the true primary ───────────────────────────
  const primaries = allClusterContacts.filter(
    (c) => c.linkPrecedence === "primary"
  );

  const truePrimary = primaries.reduce((oldest, c) =>
    c.createdAt < oldest.createdAt ? c : oldest
  );

  // ── 5. Demote competing primaries to secondary ────────────────────────────
  const demotionPromises = primaries
    .filter((p) => p._id.toString() !== truePrimary._id.toString())
    .map((p) =>
      Contact.findByIdAndUpdate(p._id, {
        linkPrecedence: "secondary",
        linkedId: truePrimary._id,
      })
    );
  await Promise.all(demotionPromises);

  // ── 6. Check if the request adds new information ──────────────────────────
  // Re-read cluster after possible demotions to get accurate email/phone sets
  const primaryIdStr = truePrimary._id.toString();
  const refreshedCluster = await findActive({
    $or: [
      { _id: { $in: [primaryIdStr] } },
      { linkedId: { $in: [primaryIdStr] } },
    ],
  });

  const existingEmails = new Set(
    refreshedCluster.map((c) => c.email).filter(Boolean)
  );
  const existingPhones = new Set(
    refreshedCluster.map((c) => c.phoneNumber).filter(Boolean)
  );

  const isNewEmail = email && !existingEmails.has(email);
  const isNewPhone = phoneNumber && !existingPhones.has(phoneNumber);

  if (isNewEmail || isNewPhone) {
    await Contact.create({
      email: email || null,
      phoneNumber: phoneNumber || null,
      linkedId: truePrimary._id,
      linkPrecedence: "secondary",
    });
  }

  // ── 7. Re-fetch final cluster and build response ──────────────────────────
  const finalCluster = await findActive({
    $or: [
      { _id: { $in: [primaryIdStr] } },
      { linkedId: { $in: [primaryIdStr] } },
    ],
  });

  const secondaries = finalCluster.filter(
    (c) => c._id.toString() !== primaryIdStr
  );

  return buildResponse(truePrimary, secondaries);
}

/**
 * findActive — wrapper that always appends .sort({ createdAt: 1 })
 * and unwraps the result to a plain array.
 */
async function findActive(query) {
  // Merge deletedAt: null into the query at the top level
  const fullQuery = { ...query, deletedAt: null };
  return Contact.find(fullQuery).sort({ createdAt: 1 });
}

/**
 * buildResponse — assembles the consolidated contact payload.
 * Primary's email/phone come first; secondaries fill in the rest.
 */
function buildResponse(primary, secondaries) {
  const emailSet = new Set();
  const phoneSet = new Set();
  const secondaryIds = [];

  if (primary.email) emailSet.add(primary.email);
  if (primary.phoneNumber) phoneSet.add(primary.phoneNumber);

  for (const s of secondaries) {
    if (s.email) emailSet.add(s.email);
    if (s.phoneNumber) phoneSet.add(s.phoneNumber);
    secondaryIds.push(s._id);
  }

  return {
    primaryContactId: primary._id,
    emails: [...emailSet],
    phoneNumbers: [...phoneSet],
    secondaryContactIds: secondaryIds,
  };
}

module.exports = { identifyContact };
