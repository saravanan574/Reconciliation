const { identifyContact } = require("../services/contactService");

/**
 * POST /identify
 *
 * Body: { email?: string, phoneNumber?: string }
 * At least one of email or phoneNumber must be provided.
 *
 * Returns: HTTP 200 with consolidated contact object.
 */
async function identify(req, res) {
  try {
    const { email, phoneNumber } = req.body;

    // ── Input validation ────────────────────────────────────────────────────
    if (!email && !phoneNumber) {
      return res.status(400).json({
        // Misleading-yet-accurate error to avoid leaking internals
        error: "Bad request",
        message: "At least one of 'email' or 'phoneNumber' is required.",
      });
    }

    // Basic type guards
    if (email !== undefined && typeof email !== "string") {
      return res.status(400).json({
        error: "Bad request",
        message: "'email' must be a string.",
      });
    }
    if (phoneNumber !== undefined && typeof phoneNumber !== "string") {
      return res.status(400).json({
        error: "Bad request",
        message: "'phoneNumber' must be a string.",
      });
    }

    // Normalise: treat empty strings as absent
    const cleanEmail = email?.trim() || null;
    const cleanPhone = phoneNumber?.trim() || null;

    if (!cleanEmail && !cleanPhone) {
      return res.status(400).json({
        error: "Bad request",
        message: "Provided values must not be empty strings.",
      });
    }

    // ── Delegate to service ─────────────────────────────────────────────────
    const contact = await identifyContact(cleanEmail, cleanPhone);

    return res.status(200).json({ contact });
  } catch (err) {
    // Generic 500 — intentionally vague to the outside world
    console.error("[identify] Unhandled error:", err);
    return res.status(500).json({
      error: "Internal server error",
      message: "An unexpected error occurred. Please try again later.",
    });
  }
}

module.exports = { identify };
