# Identity Reconciliation Service

A Node.js / Express / MongoDB microservice that implements the `/identify` endpoint for the **Bitespeed Identity Reconciliation** challenge.

---

## Problem Summary

Doc uses different emails and phone numbers for each purchase. This service links those separate contact entries into a single, consolidated identity graph — maintaining a **primary** contact and any number of **secondary** contacts.

---

## Tech Stack

| Layer      | Technology               |
|------------|--------------------------|
| Runtime    | Node.js 18+              |
| Framework  | Express.js               |
| Database   | MongoDB (via Mongoose)   |
| Testing    | Jest + Supertest + mongodb-memory-server |

---

## Project Structure

```
identity-reconciliation/
├── src/
│   ├── index.js                  # Server entry point (DB connect + listen)
│   ├── app.js                    # Express app (routes, middleware)
│   ├── models/
│   │   └── Contact.js            # Mongoose schema & model
│   ├── controllers/
│   │   └── identifyController.js # Request validation & response
│   ├── routes/
│   │   └── identify.js           # Route definitions
│   └── services/
│       └── contactService.js     # Core reconciliation logic
├── tests/
│   └── identify.test.js          # Jest integration tests
├── .env.example                  # Environment variable template
├── .gitignore
├── package.json
└── README.md
```

---

## Setup & Installation

### Prerequisites
- Node.js 18+
- MongoDB 6+ running locally **or** a MongoDB Atlas URI

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env and set your MONGODB_URI

# 3. Start the server
npm start

# 4. Development mode (auto-restart)
npm run dev
```

---

## Environment Variables

| Variable       | Default                                              | Description              |
|----------------|------------------------------------------------------|--------------------------|
| `PORT`         | `3000`                                               | HTTP port                |
| `MONGODB_URI`  | `mongodb://localhost:27017/identity_reconciliation`  | MongoDB connection string |
| `NODE_ENV`     | `development`                                        | Environment name         |

---

## API Reference

### `POST /identify`

Reconcile contact identity from email and/or phone number.

**Request Body** (JSON):
```json
{
  "email": "doc@future.com",
  "phoneNumber": "9999999999"
}
```
At least one of `email` or `phoneNumber` must be provided.

**Response `200 OK`**:
```json
{
  "contact": {
    "primaryContactId": "64abc123...",
    "emails": ["doc@future.com", "doc@zamazon.com"],
    "phoneNumbers": ["9999999999", "1234567890"],
    "secondaryContactIds": ["64abc456...", "64abc789..."]
  }
}
```

**Error Responses**:
| Status | Reason                                      |
|--------|---------------------------------------------|
| `400`  | Missing / invalid input fields              |
| `500`  | Unexpected server error                     |

---

### `GET /health`

```json
{ "status": "ok", "timestamp": "2024-01-01T00:00:00.000Z" }
```

---

## Reconciliation Logic

```
Incoming request (email / phone)
        │
        ▼
  Find contacts matching email OR phone
        │
  ┌─────┴──────┐
  │ No matches │  → Create new PRIMARY contact
  └─────┬──────┘
        │ Matches found
        ▼
  Gather full cluster (primary + all secondaries)
        │
        ▼
  Elect oldest contact as TRUE PRIMARY
        │
        ▼
  Demote competing primaries → secondary
        │
        ▼
  Does the request add new email or phone?
  ┌─────┴──────┐
  │    YES     │  → Create new SECONDARY entry
  └─────┬──────┘
        │
        ▼
  Return consolidated response
```

### Key behaviours
- **Idempotent**: identical repeated requests do not create duplicate records.
- **Cluster merging**: if a request links two previously unrelated primaries, the older one wins and the newer is demoted to secondary.
- **Soft-delete aware**: contacts with `deletedAt` set are excluded from all queries.

---

## Running Tests

Tests use an in-memory MongoDB so no real database is needed:

```bash
npm test
```

Test coverage includes:
- Input validation (missing fields, wrong types, empty strings)
- New primary creation (email-only, phone-only, both)
- Secondary creation on partial matches
- Deduplication — no duplicate secondaries on repeat calls
- Cluster merging when two independent primaries are linked
- Idempotency
- Health check endpoint
- 404 for unknown routes

---

## Example Walkthrough

```bash
# Request 1 — creates primary
curl -X POST http://localhost:3000/identify \
  -H "Content-Type: application/json" \
  -d '{"email":"doc@future.com","phoneNumber":"1111"}'

# Request 2 — same email, new phone → adds secondary
curl -X POST http://localhost:3000/identify \
  -H "Content-Type: application/json" \
  -d '{"email":"doc@future.com","phoneNumber":"2222"}'

# Request 3 — links two clusters
curl -X POST http://localhost:3000/identify \
  -H "Content-Type: application/json" \
  -d '{"email":"another@mail.com","phoneNumber":"1111"}'
```
